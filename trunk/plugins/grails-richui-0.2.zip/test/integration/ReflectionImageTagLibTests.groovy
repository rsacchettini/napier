class ReflectionImageTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}
